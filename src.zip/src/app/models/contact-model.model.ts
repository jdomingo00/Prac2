export class ContactModel {
    public id: number;
    public nom: string;
    public primerCognom: string;
    public segonCognom: string;
    public email: string;
    public tipusVia: string;
    public numero: string;
    public pis: string;
    public porta: string;
    public telefonFix: string;
    public telefonMobil: string;
}
