import { Component, OnInit } from "@angular/core";

import { ContactBookService } from "src/app/services/contact-book.service";
import { ActivatedRoute, Router } from "@angular/router";
import { ContactModel } from "src/app/models/contact-model.model";

@Component({
  selector: "app-contact-book",
  templateUrl: "./contact-book.page.html",
  styleUrls: ["./contact-book.page.scss"]
})
export class ContactBookPage implements OnInit {
  contactes: ContactModel[] = [];
  colors = [];
  constructor(
    private contactBookService: ContactBookService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.contactes = this.contactBookService.listContactes();
    this.getColors();
  }

  getColors() {
    this.colors = [];
    let num;
    for (let i = 0; i < this.contactes.length; i++) {
      num = Math.floor(Math.random() * 10 + 1);
      this.colors.push(num);
    }
    console.log(this.colors);
    return this.colors;
  }
}
