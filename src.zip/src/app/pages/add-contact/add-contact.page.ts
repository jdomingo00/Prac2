import { Component, OnInit } from "@angular/core";
import { ContactBookService } from "src/app/services/contact-book.service";
import { ContactModel } from "src/app/models/contact-model.model";

@Component({
  selector: "app-add-contact",
  templateUrl: "./add-contact.page.html",
  styleUrls: ["./add-contact.page.scss"]
})
export class AddContactPage implements OnInit {
  constructor(private contactBookService: ContactBookService) {}

  contact: ContactModel = {
    id: null,
    nom: '',
    primerCognom: '',
    segonCognom: '',
    email: '',
    tipusVia: '',
    numero: '',
    pis: '',
    porta: '',
    telefonFix: '',
    telefonMobil: ''
  };

  ngOnInit() {}

  onAddContact() {
    this.contactBookService.addContacte(this.contact);
  }
}
