import { Component, OnInit, Input } from "@angular/core";
import { ContactModel } from "src/app/models/contact-model.model";
import { ContactBookService } from "src/app/services/contact-book.service";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "app-contact",
  templateUrl: "./contact.page.html",
  styleUrls: ["./contact.page.scss"]
})
export class ContactPage implements OnInit {
  contact: ContactModel;
  constructor(
    private contactBookService: ContactBookService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    let numId = parseInt(this.route.snapshot.paramMap.get("contactId"), 10);
    if (numId) {
      this.contact = this.contactBookService.viewContact(numId);
    } else {
      this.router.navigate(["/contactes"]);
    }
  }
}
