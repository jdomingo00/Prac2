import { NgModule } from "@angular/core";
import { PreloadAllModules, RouterModule, Routes } from "@angular/router";

const routes: Routes = [
  { path: "", redirectTo: "contactes", pathMatch: "full" },
  {
    path: "contactes",
    children: [
      {
        path: "",
        loadChildren:
          "./pages/contact-book/contact-book.module#ContactBookPageModule"
      },
      {
        path: ":contactId",
        loadChildren: "./pages/contact/contact.module#ContactPageModule"
      }
    ]
  },
  {
    path: "add-contact",
    loadChildren: () =>
      import("./pages/add-contact/add-contact.module").then(
        m => m.AddContactPageModule
      )
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
