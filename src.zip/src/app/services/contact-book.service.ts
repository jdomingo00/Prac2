import { Injectable } from "@angular/core";
import { ContactModel } from "../models/contact-model.model";
import { Router } from "@angular/router";

@Injectable({
  providedIn: "root"
})
export class ContactBookService {
  contactes: ContactModel[] = [];

  constructor(private router: Router) {
    if (localStorage.getItem("contactes") != null) {
      this.contactes = JSON.parse(localStorage.getItem("contactes"));
    } else {
      this.contactes = [];
    }

    localStorage.setItem("contactes", JSON.stringify(this.contactes));
  }

  listContactes() {
    this.contactes = JSON.parse(localStorage.getItem("contactes"));

    return [...this.contactes];
  }

  viewContact(id: number) {
    return {
      ...this.contactes.find(contact => {
        return contact.id === id;
      })
    };
  }

  addContacte(contact: ContactModel) {
    if (localStorage.getItem("contactes") != null) {
      this.contactes = JSON.parse(localStorage.getItem("contactes"));
    } else {
      this.contactes = [];
    }

    this.orderId();
    contact.id = this.getLastId();
    this.contactes.push(contact);
    this.orderCognom();
    localStorage.setItem("contactes", JSON.stringify(this.contactes));

    this.router.navigate([""], { state: { data: contact } });
  }

  orderId() {
    this.contactes.sort((a: ContactModel, b: ContactModel) => {
      return a.id > b.id ? 1 : 0;
    });
  }

  getLastId() {
    if (this.contactes != null) {
      if (this.contactes.length !== 0) {
        return this.contactes[this.contactes.length - 1].id + 1;
      } else {
        return 1;
      }
    } else {
      this.contactes = [];
      return 1;
    }
  }

  orderCognom() {
    this.contactes.sort((a: ContactModel, b: ContactModel) => {
      return a.primerCognom > b.primerCognom ? 1 : 0;
    });
  }
}
