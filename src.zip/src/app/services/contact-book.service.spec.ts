import { TestBed } from '@angular/core/testing';

import { ContactBookService } from './contact-book.service';

describe('ContactBookService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContactBookService = TestBed.get(ContactBookService);
    expect(service).toBeTruthy();
  });
});
